local _, gatrQuotes = ...																									

gatrQuotes.quote = {
'Who is munyanyo?',
'Look at your hands!'
'Cancelled',
'Bing Bong!',
'My dentist just called...'
'Energy. Power. Cum. My people are addicted to it...'
'Stay in your lane, Tethal'
'It\'s going to look like I\'m hearthing'
'BITE BITE GATOR BITE'
'CYA L8R IM A G8R'
'GATOR ATTACK!'
'BITE BITE!'
'GATORS! I CHOOSE YOU!'
'JOOOOE BIDEN'
'Did you know Kentucky is the only state that starts with the letter K?'

}